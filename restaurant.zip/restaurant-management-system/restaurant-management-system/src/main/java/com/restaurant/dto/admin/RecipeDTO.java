package com.restaurant.dto.admin;

public class RecipeDTO {
}
