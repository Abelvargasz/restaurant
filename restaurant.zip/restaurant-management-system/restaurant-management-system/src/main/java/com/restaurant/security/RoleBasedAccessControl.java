package com.restaurant.security;

public class RoleBasedAccessControl {
}
