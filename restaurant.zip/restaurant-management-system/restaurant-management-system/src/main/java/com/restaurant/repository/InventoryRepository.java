package com.restaurant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.restaurant.entity.InventoryItem;
import java.util.List;
import java.util.Optional;

@Repository
public interface InventoryRepository extends JpaRepository<InventoryItem, Integer> {
    List<InventoryItem> findByBranchId(Integer branchId);
    Optional<InventoryItem> findByBranchIdAndName(Integer branchId, String name);

    @Query("SELECT i FROM InventoryItem i WHERE i.branch.id = :branchId " +
            "AND i.quantityCurrent <= i.reorderPoint")
    List<InventoryItem> findLowStockItems(@Param("branchId") Integer branchId);

    List<InventoryItem> findByStatus(InventoryItem.InventoryStatus status);
}
