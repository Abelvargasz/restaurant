package com.restaurant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.restaurant.entity.Branch;
import java.util.List;
import java.util.Optional;

@Repository
public interface BranchRepository extends JpaRepository<Branch, Integer> {
    List<Branch> findByStatus(Branch.BranchStatus status);
    Optional<Branch> findByName(String name);
    List<Branch> findByManagerId(Integer managerId);
}