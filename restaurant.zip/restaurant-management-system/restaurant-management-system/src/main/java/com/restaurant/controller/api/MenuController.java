package com.restaurant.controller.api;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.restaurant.dto.client.CategoryDTO;
import com.restaurant.dto.client.DishDTO;
import com.restaurant.entity.Category;
import com.restaurant.entity.Dish;
import com.restaurant.service.client.MenuService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/menu")
@RequiredArgsConstructor
@Slf4j
public class MenuController {

    private final MenuService menuService;

    @GetMapping("/categories")
    public ResponseEntity<List<CategoryDTO>> getAllCategories() {
        log.info("Fetching all categories");
        List<CategoryDTO> categories = menuService.getAllCategories()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(categories);
    }

    @GetMapping("/dishes")
    public ResponseEntity<List<DishDTO>> getAllDishes() {
        log.info("Fetching all dishes");
        List<DishDTO> dishes = menuService.getAllActiveDishes()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(dishes);
    }

    @GetMapping("/dishes/category/{categoryId}")
    public ResponseEntity<List<DishDTO>> getDishesByCategory(@PathVariable Integer categoryId) {
        log.info("Fetching dishes for category: {}", categoryId);
        List<DishDTO> dishes = menuService.getDishesByCategory(categoryId)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(dishes);
    }

    @GetMapping("/dishes/search")
    public ResponseEntity<List<DishDTO>> searchDishes(@RequestParam String query) {
        log.info("Searching dishes with query: {}", query);
        List<DishDTO> dishes = menuService.searchDishes(query)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(dishes);
    }

    @GetMapping("/dishes/{id}")
    public ResponseEntity<DishDTO> getDishById(@PathVariable Integer id) {
        log.info("Fetching dish: {}", id);
        return menuService.getDishById(id)
                .map(dish -> ResponseEntity.ok(mapToDTO(dish)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/featured")
    public ResponseEntity<List<DishDTO>> getFeaturedDishes() {
        log.info("Fetching featured dishes");
        List<DishDTO> dishes = menuService.getFeaturedPromotions()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(dishes);
    }

    private DishDTO mapToDTO(Dish dish) {
        return DishDTO.builder()
                .id(dish.getId())
                .name(dish.getName())
                .description(dish.getDescription())
                .price(dish.getPrice())
                .imageUrl(dish.getImageUrl())
                .estimatedPrepTimeMinutes(dish.getEstimatedPrepTimeMinutes())
                .isVegan(dish.getIsVegan())
                .isVegetarian(dish.getIsVegetarian())
                .isGlutenFree(dish.getIsGlutenFree())
                .status(dish.getStatus().toString())
                .categoryId(dish.getCategory().getId())
                .categoryName(dish.getCategory().getName())
                .build();
    }

    private CategoryDTO mapToDTO(Category category) {
        return CategoryDTO.builder()
                .id(category.getId())
                .name(category.getName())
                .description(category.getDescription())
                .iconUrl(category.getIconUrl())
                .build();
    }
}
