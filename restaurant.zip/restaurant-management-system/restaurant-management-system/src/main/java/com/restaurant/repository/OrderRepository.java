package com.restaurant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.restaurant.entity.Order;
import java.util.List;
import java.time.LocalDateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {
    List<Order> findByUserId(Integer userId);
    List<Order> findByBranchIdAndStatus(Integer branchId, Order.OrderStatus status);

    @Query("SELECT o FROM Order o WHERE o.user.id = :userId ORDER BY o.createdAt DESC")
    Page<Order> findUserOrdersPageable(@Param("userId") Integer userId, Pageable pageable);

    @Query("SELECT o FROM Order o WHERE o.branch.id = :branchId AND o.createdAt >= :startDate " +
            "AND o.createdAt <= :endDate")
    List<Order> findOrdersByBranchAndDateRange(@Param("branchId") Integer branchId,
                                               @Param("startDate") LocalDateTime startDate,
                                               @Param("endDate") LocalDateTime endDate);
}