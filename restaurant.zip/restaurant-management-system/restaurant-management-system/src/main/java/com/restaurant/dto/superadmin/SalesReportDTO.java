package com.restaurant.dto.superadmin;

public class SalesReportDTO {
}
