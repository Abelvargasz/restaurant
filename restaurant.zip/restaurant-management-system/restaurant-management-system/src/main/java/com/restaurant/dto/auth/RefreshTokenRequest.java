package com.restaurant.dto.auth;

public class RefreshTokenRequest {
}
