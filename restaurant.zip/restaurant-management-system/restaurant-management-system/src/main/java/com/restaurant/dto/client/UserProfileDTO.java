package com.restaurant.dto.client;

public class UserProfileDTO {
}
