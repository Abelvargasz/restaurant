package com.restaurant.service.client;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.restaurant.dto.client.CategoryDTO;
import com.restaurant.dto.client.DishDTO;
import com.restaurant.entity.Category;
import com.restaurant.entity.Dish;
import com.restaurant.entity.RecipeIngredient;
import com.restaurant.repository.CategoryRepository;
import com.restaurant.repository.DishRepository;
import com.restaurant.repository.RecipeRepository;
import com.restaurant.repository.RecipeIngredientRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional(readOnly = true)
public class MenuService {

    private final DishRepository dishRepository;
    private final CategoryRepository categoryRepository;
    private final RecipeRepository recipeRepository;
    private final RecipeIngredientRepository recipeIngredientRepository;

    @Cacheable(value = "activeDishes", unless = "#result == null")
    public List<Dish> getAllActiveDishes() {
        log.info("Fetching all active dishes");
        return dishRepository.findByStatus(Dish.DishStatus.ACTIVE);
    }

    public List<Dish> getDishesByCategory(Integer categoryId) {
        log.info("Fetching dishes for category: {}", categoryId);
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        return dishRepository.findByBranchIdAndCategoryId(null, categoryId);
    }

    public List<Dish> searchDishes(String search) {
        log.info("Searching dishes with term: {}", search);
        return dishRepository.searchByNameOrDescription(null, search);
    }

    public Optional<Dish> getDishById(Integer id) {
        return dishRepository.findById(id);
    }

    @Cacheable(value = "categories", unless = "#result == null")
    public List<Category> getAllCategories() {
        log.info("Fetching all categories");
        return categoryRepository.findByStatus(Category.CategoryStatus.ACTIVE);
    }

    public List<RecipeIngredient> getRecipeIngredients(Integer dishId) {
        log.info("Fetching recipe ingredients for dish: {}", dishId);
        return recipeRepository.findByDishId(dishId)
                .map(recipe -> recipeIngredientRepository.findByRecipeId(recipe.getId()))
                .orElse(List.of());
    }

    public List<Dish> getTopSellingDishes(int limit) {
        log.info("Fetching top {} selling dishes", limit);
        return dishRepository.findByStatus(Dish.DishStatus.ACTIVE)
                .stream()
                .limit(limit)
                .collect(Collectors.toList());
    }

    public List<Dish> getFeaturedPromotions() {
        log.info("Fetching featured promotions");
        return dishRepository.findByStatus(Dish.DishStatus.ACTIVE)
                .stream()
                .limit(5)
                .collect(Collectors.toList());
    }
}
