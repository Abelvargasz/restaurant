package com.restaurant.dto.client;

import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderResponseDTO {
    private Integer id;
    private String orderNumber;
    private String status;
    private List<CartItemDTO> items;
    private BigDecimal subtotal;
    private BigDecimal igvTax;
    private BigDecimal deliveryFee;
    private BigDecimal total;
    private String deliveryAddress;
    private String paymentMethod;
    private Integer estimatedDeliveryTimeMinutes;
    private LocalDateTime createdAt;
}