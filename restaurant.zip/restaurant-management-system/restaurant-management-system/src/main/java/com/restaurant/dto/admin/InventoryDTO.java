package com.restaurant.dto.admin;

import lombok.*;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventoryDTO {
    private Integer id;
    private String name;
    private String unit;
    private BigDecimal quantityCurrent;
    private BigDecimal quantityMin;
    private BigDecimal quantityMax;
    private BigDecimal unitCost;
    private String status;
    private Integer supplierId;
}
