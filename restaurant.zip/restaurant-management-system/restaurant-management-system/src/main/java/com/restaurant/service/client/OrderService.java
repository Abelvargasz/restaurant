package com.restaurant.service.client;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.restaurant.dto.client.OrderRequestDTO;
import com.restaurant.dto.client.OrderResponseDTO;
import com.restaurant.entity.Order;
import com.restaurant.entity.OrderItem;
import com.restaurant.entity.User;
import com.restaurant.entity.Dish;
import com.restaurant.entity.Address;
import com.restaurant.repository.OrderRepository;
import com.restaurant.repository.OrderItemRepository;
import com.restaurant.repository.UserRepository;
import com.restaurant.repository.DishRepository;
import com.restaurant.repository.AddressRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final UserRepository userRepository;
    private final DishRepository dishRepository;
    private final AddressRepository addressRepository;

    @Transactional
    public OrderResponseDTO createOrder(String userEmail, OrderRequestDTO request) {
        log.info("Creating order for user: {}", userEmail);

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Order order = Order.builder()
                .user(user)
                .status(Order.OrderStatus.PENDING)
                .deliveryAddress(request.getDeliveryAddress())
                .paymentMethod(Order.PaymentMethod.valueOf(request.getPaymentMethod()))
                .notes(request.getNotes())
                .build();

        // Calcular totales
        BigDecimal subtotal = BigDecimal.ZERO;
        for (var item : request.getItems()) {
            Dish dish = dishRepository.findById(item.getDishId())
                    .orElseThrow(() -> new RuntimeException("Dish not found"));

            OrderItem orderItem = OrderItem.builder()
                    .order(order)
                    .dish(dish)
                    .quantity(item.getQuantity())
                    .unitPrice(dish.getPrice())
                    .subtotal(dish.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
                    .specialNotes(item.getSpecialNotes())
                    .build();

            order.getItems().add(orderItem);
            subtotal = subtotal.add(orderItem.getSubtotal());
        }

        order.setSubtotal(subtotal);
        order.setIgvTax(subtotal.multiply(new BigDecimal("0.18")));
        order.setDeliveryFee(new BigDecimal("5.00"));
        order.setTotal(subtotal.add(order.getIgvTax()).add(order.getDeliveryFee()));
        order.setEstimatedDeliveryTimeMinutes(30);

        Order savedOrder = orderRepository.save(order);
        log.info("Order created successfully with ID: {}", savedOrder.getId());

        return convertToDTO(savedOrder);
    }

    public List<OrderResponseDTO> getUserOrders(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return orderRepository.findByUserId(user.getId())
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<Address> getUserAddresses(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return addressRepository.findByUserId(user.getId());
    }

    public List<String> getAvailablePaymentMethods() {
        return List.of("IN_LOCAL", "CARD", "TRANSFER", "YAPE", "PLIN");
    }

    private OrderResponseDTO convertToDTO(Order order) {
        return OrderResponseDTO.builder()
                .id(order.getId())
                .orderNumber("ORD-" + order.getId())
                .status(order.getStatus().toString())
                .subtotal(order.getSubtotal())
                .igvTax(order.getIgvTax())
                .deliveryFee(order.getDeliveryFee())
                .total(order.getTotal())
                .deliveryAddress(order.getDeliveryAddress())
                .paymentMethod(order.getPaymentMethod().toString())
                .estimatedDeliveryTimeMinutes(order.getEstimatedDeliveryTimeMinutes())
                .createdAt(order.getCreatedAt())
                .build();
    }
}
