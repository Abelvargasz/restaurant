package com.restaurant.dto.client;

import lombok.*;
import jakarta.validation.constraints.*;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderRequestDTO {
    @NotNull(message = "Branch ID is required")
    private Integer branchId;

    @NotBlank(message = "Delivery address is required")
    private String deliveryAddress;

    @NotNull(message = "Payment method is required")
    private String paymentMethod;

    private String notes;

    @NotEmpty(message = "Order must have at least one item")
    private List<CartItemDTO> items;
}