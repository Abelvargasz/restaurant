package com.restaurant.dto.auth;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoginResponse {
    private String token;
    private String refreshToken;
    private Integer userId;
    private String email;
    private String fullName;
    private String role;
}