package com.restaurant.controller.web;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import com.restaurant.service.client.MenuService;
import com.restaurant.service.client.OrderService;

@Controller
@RequiredArgsConstructor
@Slf4j
public class WebController {

    private final MenuService menuService;
    private final OrderService orderService;

    // ==========================================
    // PUBLIC PAGES
    // ==========================================

    @GetMapping("")
    public String home(Model model) {
        log.info("Rendering home page");
        model.addAttribute("categories", menuService.getAllCategories());
        model.addAttribute("topDishes", menuService.getTopSellingDishes(6));
        model.addAttribute("featuredDishes", menuService.getFeaturedPromotions());
        return "client/home";
    }

    @GetMapping("/menu")
    public String menu(
            @RequestParam(value = "category", required = false) Integer categoryId,
            @RequestParam(value = "search", required = false) String search,
            Model model) {
        log.info("Rendering menu page");

        if (search != null && !search.isEmpty()) {
            model.addAttribute("dishes", menuService.searchDishes(search));
            model.addAttribute("searchTerm", search);
        } else if (categoryId != null) {
            model.addAttribute("dishes", menuService.getDishesByCategory(categoryId));
            model.addAttribute("selectedCategory", categoryId);
        } else {
            model.addAttribute("dishes", menuService.getAllActiveDishes());
        }

        model.addAttribute("categories", menuService.getAllCategories());
        return "client/menu";
    }

    @GetMapping("/dish/{id}")
    public String dishDetail(@PathVariable Integer id, Model model) {
        log.info("Rendering dish detail for ID: {}", id);

        menuService.getDishById(id).ifPresentOrElse(
                dish -> {
                    model.addAttribute("dish", dish);
                    model.addAttribute("ingredients", menuService.getRecipeIngredients(id));
                },
                () -> {
                    model.addAttribute("error", "Dish not found");
                }
        );

        return "client/dish-detail";
    }

    @GetMapping("/login")
    public String loginPage() {
        log.info("Rendering login page");
        return "auth/login";
    }

    @GetMapping("/register")
    public String registerPage() {
        log.info("Rendering register page");
        return "auth/register";
    }

    // ==========================================
    // PROTECTED PAGES (Require Authentication)
    // ==========================================

    @GetMapping("/cart")
    public String cart(Model model, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        log.info("Rendering cart page");
        model.addAttribute("userName", authentication.getName());
        return "client/cart";
    }

    @GetMapping("/checkout")
    public String checkout(Model model, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        log.info("Rendering checkout page");
        model.addAttribute("paymentMethods", orderService.getAvailablePaymentMethods());
        model.addAttribute("userName", authentication.getName());
        return "client/checkout";
    }

    @GetMapping("/orders")
    public String userOrders(Model model, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        log.info("Rendering user orders page");
        model.addAttribute("orders", orderService.getUserOrders(authentication.getName()));
        model.addAttribute("userName", authentication.getName());
        return "client/orders";
    }

    @GetMapping("/order/{id}")
    public String orderDetail(@PathVariable Integer id, Model model, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        log.info("Rendering order detail for ID: {}", id);
        model.addAttribute("userName", authentication.getName());
        return "client/order-detail";
    }

    @GetMapping("/profile")
    public String profile(Model model, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        log.info("Rendering user profile page");
        model.addAttribute("userName", authentication.getName());
        return "client/profile";
    }

    // ==========================================
    // ADMIN PAGES
    // ==========================================

    @GetMapping("/admin/dashboard")
    public String adminDashboard(Model model, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        log.info("Rendering admin dashboard");
        model.addAttribute("userName", authentication.getName());
        return "admin/dashboard";
    }

    @GetMapping("/admin/orders")
    public String adminOrders(Model model, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        log.info("Rendering admin orders page");
        model.addAttribute("userName", authentication.getName());
        return "admin/orders";
    }

    @GetMapping("/admin/inventory")
    public String adminInventory(Model model, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        log.info("Rendering admin inventory page");
        model.addAttribute("userName", authentication.getName());
        return "admin/inventory";
    }

    @GetMapping("/admin/menu")
    public String adminMenu(Model model, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        log.info("Rendering admin menu management page");
        model.addAttribute("categories", menuService.getAllCategories());
        model.addAttribute("userName", authentication.getName());
        return "admin/menu";
    }
}
