package com.restaurant.service.auth;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.restaurant.dto.auth.LoginRequest;
import com.restaurant.dto.auth.LoginResponse;
import com.restaurant.dto.auth.RegisterRequest;
import com.restaurant.entity.User;
import com.restaurant.entity.Role;
import com.restaurant.repository.UserRepository;
import com.restaurant.repository.RoleRepository;
import com.restaurant.security.JwtTokenProvider;

import java.util.HashSet;
import java.util.Set;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider tokenProvider;

    @Transactional
    public LoginResponse login(LoginRequest request) {
        log.info("Attempting login for email: {}", request.getEmail());

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        String role = user.getRoles().isEmpty() ? "ROLE_CLIENT" :
                user.getRoles().iterator().next().getName();

        String token = tokenProvider.generateToken(user.getEmail(), role);
        String refreshToken = tokenProvider.generateRefreshToken(user.getEmail());

        return LoginResponse.builder()
                .token(token)
                .refreshToken(refreshToken)
                .userId(user.getId())
                .email(user.getEmail())
                .fullName(user.getFirstName() + " " + user.getLastName())
                .role(role)
                .build();
    }

    @Transactional
    public LoginResponse register(RegisterRequest request) {
        log.info("Registering new user with email: {}", request.getEmail());

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already registered");
        }

        User user = User.builder()
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .phone(request.getPhone())
                .status(User.UserStatus.ACTIVE)
                .build();

        // Asignar rol de cliente por defecto
        Role clientRole = roleRepository.findByName("ROLE_CLIENT")
                .orElseGet(() -> {
                    Role newRole = Role.builder()
                            .name("ROLE_CLIENT")
                            .description("Client role")
                            .build();
                    return roleRepository.save(newRole);
                });

        user.setRoles(new HashSet<>(Set.of(clientRole)));
        User savedUser = userRepository.save(user);

        String token = tokenProvider.generateToken(savedUser.getEmail(), "ROLE_CLIENT");
        String refreshToken = tokenProvider.generateRefreshToken(savedUser.getEmail());

        return LoginResponse.builder()
                .token(token)
                .refreshToken(refreshToken)
                .userId(savedUser.getId())
                .email(savedUser.getEmail())
                .fullName(savedUser.getFirstName() + " " + savedUser.getLastName())
                .role("ROLE_CLIENT")
                .build();
    }
}