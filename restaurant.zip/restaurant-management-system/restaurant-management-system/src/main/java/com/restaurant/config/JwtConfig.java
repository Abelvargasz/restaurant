package com.restaurant.config;

public class JwtConfig {
}
