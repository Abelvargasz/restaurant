package com.restaurant.dto.admin;

public class OrderManagementDTO {
}
