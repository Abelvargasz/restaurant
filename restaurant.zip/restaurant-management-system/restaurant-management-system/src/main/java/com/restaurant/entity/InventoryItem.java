package com.restaurant.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "inventory_items")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventoryItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "branch_id", nullable = false)
    private Branch branch;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String unit;

    @Column(name = "quantity_current", columnDefinition = "DECIMAL(15,2) DEFAULT 0")
    private BigDecimal quantityCurrent = BigDecimal.ZERO;

    @Column(name = "quantity_min")
    private BigDecimal quantityMin;

    @Column(name = "quantity_max")
    private BigDecimal quantityMax;

    @Column(name = "unit_cost")
    private BigDecimal unitCost;

    @Column(name = "supplier_id")
    private Integer supplierId;

    @Column(name = "reorder_point")
    private BigDecimal reorderPoint;

    @Enumerated(EnumType.STRING)
    @Column(columnDefinition = "VARCHAR(20) DEFAULT 'AVAILABLE'")
    private InventoryStatus status = InventoryStatus.AVAILABLE;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public enum InventoryStatus {
        AVAILABLE, LOW, OUT_OF_STOCK, EXPIRED
    }
}
