package com.restaurant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.restaurant.entity.Dish;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;

@Repository
public interface DishRepository extends JpaRepository<Dish, Integer> {
    List<Dish> findByBranchIdAndStatus(Integer branchId, Dish.DishStatus status);
    List<Dish> findByBranchIdAndCategoryId(Integer branchId, Integer categoryId);
    List<Dish> findByStatus(Dish.DishStatus status);

    @Query("SELECT d FROM Dish d WHERE d.branch.id = :branchId AND d.status = 'ACTIVE' " +
            "AND (LOWER(d.name) LIKE LOWER(CONCAT('%', :search, '%')) " +
            "OR LOWER(d.description) LIKE LOWER(CONCAT('%', :search, '%')))")
    List<Dish> searchByNameOrDescription(@Param("branchId") Integer branchId,
                                         @Param("search") String search);

    @Query("SELECT d FROM Dish d WHERE d.branch.id = :branchId AND d.status = 'ACTIVE'")
    Page<Dish> findActiveDishesInBranch(@Param("branchId") Integer branchId, Pageable pageable);
}