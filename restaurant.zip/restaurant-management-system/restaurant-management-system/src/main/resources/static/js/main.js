class RestaurantAPI {
    constructor() {
        this.baseUrl = '/api';
        this.token = localStorage.getItem('token');
    }

    // ==========================================
    // AUTHENTICATION
    // ==========================================

    async login(email, password) {
        try {
            const response = await fetch(`${this.baseUrl}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            if (response.ok) {
                const data = await response.json();
                localStorage.setItem('token', data.token);
                localStorage.setItem('refreshToken', data.refreshToken);
                localStorage.setItem('userEmail', data.email);
                this.token = data.token;
                return data;
            }
            throw new Error('Login failed');
        } catch (error) {
            console.error('Login error:', error);
            throw error;
        }
    }

    async register(userData) {
        try {
            const response = await fetch(`${this.baseUrl}/auth/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });

            if (response.ok) {
                const data = await response.json();
                localStorage.setItem('token', data.token);
                localStorage.setItem('refreshToken', data.refreshToken);
                this.token = data.token;
                return data;
            }
            throw new Error('Registration failed');
        } catch (error) {
            console.error('Register error:', error);
            throw error;
        }
    }

    // ==========================================
    // MENU & DISHES
    // ==========================================

    async getCategories() {
        try {
            const response = await fetch(`${this.baseUrl}/menu/categories`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching categories:', error);
            return [];
        }
    }

    async getDishes() {
        try {
            const response = await fetch(`${this.baseUrl}/menu/dishes`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching dishes:', error);
            return [];
        }
    }

    async getDishesByCategory(categoryId) {
        try {
            const response = await fetch(`${this.baseUrl}/menu/dishes/category/${categoryId}`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching dishes by category:', error);
            return [];
        }
    }

    async searchDishes(query) {
        try {
            const response = await fetch(`${this.baseUrl}/menu/dishes/search?query=${query}`);
            return await response.json();
        } catch (error) {
            console.error('Error searching dishes:', error);
            return [];
        }
    }

    async getDishById(id) {
        try {
            const response = await fetch(`${this.baseUrl}/menu/dishes/${id}`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching dish:', error);
            return null;
        }
    }

    // ==========================================
    // ORDERS
    // ==========================================

    async createOrder(orderData) {
        try {
            const response = await fetch(`${this.baseUrl}/client/orders`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`
                },
                body: JSON.stringify(orderData)
            });

            if (response.ok) {
                return await response.json();
            }
            throw new Error('Failed to create order');
        } catch (error) {
            console.error('Error creating order:', error);
            throw error;
        }
    }

    async getUserOrders() {
        try {
            const response = await fetch(`${this.baseUrl}/client/orders`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });
            return await response.json();
        } catch (error) {
            console.error('Error fetching orders:', error);
            return [];
        }
    }

    async getPaymentMethods() {
        try {
            const response = await fetch(`${this.baseUrl}/client/orders/payment-methods`);
            return await response.json();
        } catch (error) {
            console.error('Error fetching payment methods:', error);
            return [];
        }
    }

    // ==========================================
    // CART MANAGEMENT
    // ==========================================

    getCart() {
        return JSON.parse(localStorage.getItem('cart') || '[]');
    }

    saveCart(cart) {
        localStorage.setItem('cart', JSON.stringify(cart));
        this.updateCartUI();
    }

    addToCart(dish) {
        const cart = this.getCart();
        const existingItem = cart.find(item => item.id === dish.id);

        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                ...dish,
                quantity: 1
            });
        }

        this.saveCart(cart);
        this.showNotification(`${dish.name} agregado al carrito`, 'success');
    }

    removeFromCart(dishId) {
        let cart = this.getCart();
        cart = cart.filter(item => item.id !== dishId);
        this.saveCart(cart);
    }

    updateCartItem(dishId, quantity) {
        const cart = this.getCart();
        const item = cart.find(item => item.id === dishId);

        if (item) {
            if (quantity <= 0) {
                this.removeFromCart(dishId);
            } else {
                item.quantity = quantity;
                this.saveCart(cart);
            }
        }
    }

    clearCart() {
        localStorage.removeItem('cart');
        this.updateCartUI();
    }

    getCartTotal() {
        const cart = this.getCart();
        return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    updateCartUI() {
        const cart = this.getCart();
        const cartCount = document.getElementById('cartCount');

        if (cartCount) {
            if (cart.length > 0) {
                cartCount.textContent = cart.length;
                cartCount.style.display = 'flex';
            } else {
                cartCount.style.display = 'none';
            }
        }
    }

    // ==========================================
    // NOTIFICATIONS
    // ==========================================

    showNotification(message, type = 'info') {
        // Crear elemento de notificación
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show`;
        notification.style.position = 'fixed';
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.zIndex = '9999';
        notification.style.minWidth = '300px';

        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

        document.body.appendChild(notification);

        // Auto-cerrar después de 3 segundos
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    // ==========================================
    // UTILITY FUNCTIONS
    // ==========================================

    logout() {
        localStorage.removeItem('token');
        localStorage.removeItem('refreshToken');
        localStorage.removeItem('userEmail');
        localStorage.removeItem('cart');
        this.token = null;
        window.location.href = '/login';
    }

    isLoggedIn() {
        return !!this.token;
    }

    getAuthHeader() {
        return {
            'Authorization': `Bearer ${this.token}`
        };
    }
}

// Instancia global
const api = new RestaurantAPI();

// =================
